<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    
<body>
    <header>
        <h1>Visita Cliente</h1>
        <form method="post" action="" style="display: right;">
        <button type="button" id="volver" onclick="window.location.href='pagina1.php'">Volver</button>
        </form>
    </header>

    
   </div>
        

    </form>
